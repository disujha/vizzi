exports.handler = async (event) => {
  console.log("DefineAuthChallenge event:", JSON.stringify(event));

  if (event.request.session.length === 0) {
    event.response.issueTokens = false;
    event.response.failAuthentication = false;
    event.response.challengeName = "CUSTOM_CHALLENGE";

  } else if (
    event.request.session.length === 1 &&
    event.request.session[0].challengeResult === true
  ) {
    event.response.issueTokens = true;
    event.response.failAuthentication = false;

  } else {
    event.response.issueTokens = false;
    event.response.failAuthentication = true;
  }

  return event;
};